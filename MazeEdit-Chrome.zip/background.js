let states = {};

chrome.action.onClicked.addListener(async (tab) => {
  const on = !states[tab.id];
  states[tab.id] = on;

  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: (enabled) => {
      document.designMode = enabled ? 'on' : 'off';
    },
    args: [on]
  });

  chrome.action.setTitle({
    tabId: tab.id,
    title: on ? "MazeEdit — ON (click to turn off)" : "MazeEdit"
  });
  chrome.action.setBadgeText({ tabId: tab.id, text: on ? "ON" : "" });
  chrome.action.setBadgeBackgroundColor({ tabId: tab.id, color: "#7c6aff" });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === "loading") {
    states[tabId] = false;
    chrome.action.setBadgeText({ tabId, text: "" });
  }
});
